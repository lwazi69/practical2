package com.example.practical

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.practical.R.id.btnBacktomain

class detailedview : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detailedview)

        val dayOfweek = intent.getStringArrayExtra("dayOfWeek")
        val minTemperature = intent.getIntExtra("mintemperature",0)
        val maxTemperature = intent.getIntExtra("maxTemperature",0)
        val weatherConditions = intent.getStringExtra("weatherCondition")

        val dayTextView: String ="Day:$dayOfweek"
        val minTemperatureTextView: String ="$minTemperature"
        val maxTemperatureTextView ="$maxTemperature"
        val weatherConditionsTextView ="$weatherConditions"

        val btnBacktomain=findViewById<Button>(R.id.btnBacktomain)
        btnBacktomain.setOnClickListener {
        val int=Intent (this,mainscreen::class.java)
            startActivity(int)

        }





    }
}