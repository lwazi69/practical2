package com.example.practical

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.practical.R.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.splashactivity)

        val btnNext= findViewById<Button>(R.id.btnNext)
        btnNext.setOnClickListener {
            val int= Intent (this,mainscreen::class.java)
            startActivity(int)




        }



    }
}