package com.example.practical

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class mainscreen<Button> : AppCompatActivity() {
      private val daysofWeek= arrayOf("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday")
      private val minTemparatures= intArrayOf(7,15)
      private val maxTemperatures= intArrayOf(22,32)
      private val weatherConditions= intArrayOf("Sunny", "Windy")

    private fun intArrayOf(o: , elements: String): IntArray {

    }


    private fun calculateAverageTemperature(): Int {
        var sum = 0
        for (i in minTemparatures.indices) {
            sum += (minTemparatures[i] + maxTemperatures[i]) / 2
        }
        return sum / minTemparatures.size

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mainscreen)

        val averageTemperature= calculateAverageTemperature()
        "average temperature:$averageTemperature$".also { it.also {  = it } }



            val btnEnter=findViewById<Button>(R.id.btnEnter)
            btnEnter.setOnClickListner {
                val int=Intent(this,detailedview)
                startActivity(int)


        }





    }



    }









